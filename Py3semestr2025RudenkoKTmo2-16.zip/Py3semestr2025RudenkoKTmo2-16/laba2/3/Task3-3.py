# Задача 1
a = int(input("Введите целое число: "))
s = 0
k = 0
while (a != 0):
    s += a
    k += 1
    a = int(input("Введите целое число: "))
print(f"Сумма = {s} и количество введенных чисел из последовательности = {k}")

# C:\Users\korudenko\PycharmProjects\Py3semestr2025RudenkoKTmo2-16\.venv\Scripts\python.exe C:\Users\korudenko\PycharmProjects\Py3semestr2025RudenkoKTmo2-16\laba2\3\Task3-3.py
# Введите целое число: 1
# Введите целое число: 3
# Введите целое число: 0
# Сумма = 4 и количество введенных чисел из последовательности = 2
#
# Process finished with exit code 0
