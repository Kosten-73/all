print('x y z w f')
for x in 0,1:
    for y in 0,1:
        for z in 0,1:
            for w in 0,1:
                if((x==(y>=z))and(y == (not(z >= w)))) :
                    print(x,y,z,w, ((x==(y>=z))and(y == (not(z >= w)))))