import java.util.HashMap;

public class Main {
    public boolean max(int a, int b) {
        if(a > b) {
            return true;
        } else if(a == b) {
            return false;
        } else {
            return false;
        }
    }
}